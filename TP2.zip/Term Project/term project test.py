from cmu_112_graphics import *
from tkinter import *
import random

class Fruit(object):
    def __init__(self, fruitName):
        self.cx = random.randint(mode.width//5, mode.width*4//5)
        mode.cy = mode.height
        self.fruitName = fruitName
        self.r = 40
        
        self.watermelon = PhotoImage(file = 'Watermelon.png')
        self.watermelon_bit1 = PhotoImage(file = 'Watermelon_Bit1.png')
        self.watermelon_bit2 = PhotoImage(file = 'Watermelon_Bit2.png')

        self.mango = PhotoImage(file = 'Mango.png')
        self.mango_bit1 = PhotoImage(file = 'Mango_Bit1.png')
        mode.mango_bit2 = PhotoImage(file = 'Mango_Bit2.png')

        self.pineapple = PhotoImage(file = 'Pineapple.png')
        self.pineapple_bit1 = PhotoImage(file = 'Pineapple_Bit1.png')
        self.pineapple_bit2 = PhotoImage(file = 'Pineapple_Bit2.png')

        self.coconut = PhotoImage(file = 'Coconut.png')
        self.coconut_bit1 = PhotoImage(file = 'Coconut_Bit1.png')
        self.coconut_bit2 = PhotoImage(file = 'Coconut_Bit2.png')

        self.strawberry = PhotoImage(file = 'Strawberry.png')
        self.strawberry_bit1 = PhotoImage(file = 'Strawberry_Bit1.png')
        self.strawberry_bit2 = PhotoImage(file = 'Strawberry_Bit2.png')

        self.fruits = {'watermelon':mode.watermelon,'mango':mode.mango,
                  'pineapple':mode.pineapple,
                  'coconut':mode.coconut,'strawberry':mode.strawberry}

        self.bit1 = {'watermelon':mode.watermelon_bit1,'mango':mode.mango_bit1,
                'pineapple':mode.pineapple_bit1,'coconut':mode.coconut_bit1,
                'strawberry':mode.strawberry_bit1}

        self.bit2 = {'watermelon':mode.watermelon_bit2, 'mango':mode.mango_bit2,
                'pineapple':mode.pineapple_bit2,'coconut':mode.coconut_bit2,
                'strawberry':mode.strawberry_bit2}
        
        self.image = self.fruits[self.fruitName]

    def drawFruit(self, canvas):
        canvas.create_image(self.cx,self.cy, image = self.image)

    def doMove(self):
        mode.cy -= mode.dy1
        mode.cx += mode.dx
        if mode.cy < mode.maxheight:
            mode.dy1 = -mode.dy1

    def checkCollision(self, mouseX, mouseY):
        dist = ((mode.cx - mouseX)**2 + (mode.cy - mouseY)**2)**.5
        if dist <= self.r:
            return True
        else:
            return False

class StartScreenMode(Mode):
    def redrawAll(mode, canvas):
        mode.background = PhotoImage(file ='Background.png')
        canvas.create_image(300,200,image=mode.background)
        font = 'Arial 26 bold'
        canvas.create_text(mode.width/2,
                           100, text='Fruit Ninja!', font=font)
        mode.watermelon = PhotoImage(file = 'Watermelon.png')
        canvas.create_image(mode.width/2,mode.height*3/4,
                            image = mode.watermelon)
        canvas.create_text(mode.width/2, mode.height*3/4, text = 'START GAME',
                           font = 'Arial 7 bold')

    def mousePressed(mode, event):
        if (event.x < mode.width/2+50 and event.x > mode.width/2-50 and
            event.y < mode.height*3/4+50 and event.y > mode.height*3/4-50):
            mode.app.setActiveMode(mode.app.gameMode)

class GameMode(Mode):
    def appStarted(mode):
        mode.score = 0
        mode.dy1 = random.randint(30,40)
        mode.dy2 = random.randint(30,40)
        mode.maxheight = random.randint(mode.height//3, mode.height*2//3)
        mode.dx = random.randint(5,15)
        mode.by = mode.height
        mode.bx = random.randint(mode.width//5, mode.width*4//5)
        mode.r = 40
        mode.lives = 3
        mode.counter = 0
        mode.fruitList = []
        mode.addFruit()
        mode.bombList = []
        mode.bomb()

    def randFruit(mode):
        mode.fruitChoice=random.choice(['watermelon','mango','pineapple',
                                       'coconut','strawberry'])

    def addFruit(mode):
        for i in range(random.randint(1,5)):
            mode.fruitList(Fruit(mode.fruitChoice))

    def bomb(mode):
        mode.bomb = PhotoImage(file = 'Bomb.png')
        

    def timerFired(mode):
        for fruit in fruitList:
            fruit.doMove()
            mode.counter += 1
            #print (mode.counter)
            if mode.counter >= random.choice([50,50,50,75,75,100,100,150]):
                mode.fruitList.append(Fruit(mode.fruitChoice))
                #mode.bombList.append('Bomb.png')
                mode.counter = 0
            elif mode.cy == mode.height:
                mode.lives -= 1
                mode.fruitList.append(Fruit(mode.fruitChoice))
                mode.dy1 = abs(mode.dy1)
                fruit.cx = random.randint(mode.width//5, mode.width*4//5)
            elif mode.lives == 0:
                mode.app.setActiveMode(mode.app.gameOverMode)
            

    def mouseDragged(mode, event):
        #for fruit in mode.fruitList:
        for fruit in mode.fruitList:
            if fruit.checkCollision(event.x, event.y) == True:
                mode.score += 1
##            dist = ((mode.cx - event.x)**2 + (mode.cy - event.y)**2)**.5
##            dist2 = ((mode.bx - event.x)**2 + (mode.by - event.y)**2)**.5
##            if dist <= mode.r:
##                mode.score += 1
##                #mode.fruitList.pop()
##                print (mode.fruits)
##                mode.cx = random.randint(mode.width//5, mode.width*4//5)
##                mode.cy = mode.height
##                mode.dy1 = abs(mode.dy1)
##                mode.randomFruit()
##            if dist2 <= mode.r:
##                mode.lives = 0
##                mode.app.setActiveMode(mode.app.gameOverMode)

    def redrawAll(mode, canvas):
        mode.background = PhotoImage(file ='Background.png')
        canvas.create_image(300,200,image=mode.background)
        canvas.create_text(mode.width/5, mode.height/8,
                           text = f'Score: {mode.score}',font = 'Arial 26 bold')
        canvas.create_text(mode.width*4/5, mode.height/8,
                           text = f'Lives: {mode.lives}',font = 'Arial 26 bold')
        for fruit in mode.fruitList:
            #print(fruit)
            fruit.drawFruit()
        #for bomb in mode.bombList:
        canvas.create_image(mode.bx,mode.by,image=mode.bomb)

class GameOverMode(Mode):
    def redrawAll(mode,canvas):
        mode.background = PhotoImage(file ='Background.png')
        canvas.create_image(300,200,image=mode.background)
        font = 'Arial 26 bold'
        canvas.create_text(mode.width/2,
                           100, text='Game Over!', font=font)
        canvas.create_text(mode.width/2, 150,
                           text = f'Score: 0',#{GameMode.score}',
                           font = font)
            
    
class MyModalApp(ModalApp):
    def appStarted(app):
        app.startScreenMode = StartScreenMode()
        app.gameMode = GameMode()
        app.gameOverMode = GameOverMode()
        app.setActiveMode(app.startScreenMode)

MyModalApp(width = 600, height = 400)
