from cmu_112_graphics import *
from tkinter import *
import random

class Bits(object):
    def __init__(self, startx, starty, dx, dy, image):
        self.x1 = startx
        self.x2 = startx
        self.dx = 2*dx
        self.dy = dy
        self.y = starty
        
    def doMove(self):
        self.x1 -= self.dx
        self.x2 += self.dx
        if mode.cy < mode.maxheight:
            mode.dy1 = -mode.dy1

    def drawFruit(self, canvas):
        canvas.create_image(mode.cx,mode.cy,image=mode.watermelon_bit1)
        canvas.create_image(mode.cx,mode.cy,image=mode.watermelon_bit2)


class GameMode(Mode):
    def appStarted(mode):
        mode.score = 0
        mode.dy1 = random.randint(35,45)
        mode.dy2 = random.randint(30,40)
        mode.cy = mode.height
        mode.maxheight = random.randint(mode.height//3, mode.height*2//3)
        mode.cx = random.randint(mode.width//5, mode.width*4//5)
        mode.dx = random.randint(20,25)
        mode.by = mode.height
        mode.bx = random.randint(mode.width//5, mode.width*4//5)
        mode.bitx1 = 0
        mode.bitx2 = 0
        mode.bity = 0
        mode.r = 40
        mode.lives = 3
        mode.counter = 0
        mode.fruitList = []
        mode.isCut = False
        mode.randomFruit()

    def randomFruit(mode):
        mode.fruitList = []
        #images are from https://fruitninja.fandom.com/wiki/Category:Fruit

        mode.watermelon = PhotoImage(file = 'Watermelon.png')
        mode.watermelon_bit1 = PhotoImage(file = 'Watermelon_Bit1.png')
        mode.watermelon_bit2 = PhotoImage(file = 'Watermelon_Bit2.png')

        mode.image = mode.watermelon

    def timerFired(mode):
        mode.doMove()
        mode.counter += 1
        if mode.counter >= random.choice([50,50,50,75,75,100,100,150]):
            mode.randomFruit()
            #mode.bombList.append(mode.bomb)
            mode.counter = 0
        elif mode.cy == mode.height:
            mode.lives -= 1
            mode.randomFruit()
            mode.dy1 = abs(mode.dy1)
            mode.cx = random.randint(mode.width//5, mode.width*4//5)
            
    def doMove(mode):
        mode.cy -= mode.dy1
        mode.cx += mode.dx
        if mode.cy < mode.maxheight:
            mode.dy1 = -mode.dy1

    def mouseDragged(mode, event):
        #for fruit in mode.fruitList:
            dist = ((mode.cx - event.x)**2 + (mode.cy - event.y)**2)**.5
            if dist <= mode.r:
                mode.score += 1
                #mode.fruitList.pop(fruitList.index(fruit))
                #print (mode.fruitChoice)
                #mode.cx = random.randint(mode.width//5, mode.width*4//5)
                #mode.cy = mode.height
                mode.dy1 = abs(mode.dy1)
                mode.isCut = True
                mode.randomFruit()

    def redrawAll(mode, canvas):
        mode.background = PhotoImage(file ='Background.png')
        canvas.create_image(300,200,image=mode.background)
        canvas.create_text(mode.width/5, mode.height/8,
                           text = f'Score: {mode.score}',font = 'Arial 26 bold')
        canvas.create_text(mode.width*4/5, mode.height/8,
                           text = f'Lives: {mode.lives}',font = 'Arial 26 bold')
        #for fruit in mode.fruitList:
            #print(fruit)
        if mode.isCut == False:
            canvas.create_image(mode.cx,mode.cy,image=mode.watermelon)
        else:
            
        
            
    
class MyModalApp(ModalApp):
    def appStarted(app):
        app.gameMode = GameMode()
        app.setActiveMode(app.gameMode)

MyModalApp(width = 600, height = 400)
