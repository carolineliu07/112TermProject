from cmu_112_graphics import *
from tkinter import *
import random

class StartScreenMode(Mode):
    def redrawAll(mode, canvas):
        mode.background = PhotoImage(file ='Background.png')
        canvas.create_image(300,200,image=mode.background)
        font = 'Arial 26 bold'
        canvas.create_text(mode.width/2,
                           100, text='Fruit Ninja!', font=font)
        mode.watermelon = PhotoImage(file = 'Watermelon.png')
        canvas.create_image(mode.width/2,mode.height*3/4,
                            image = mode.watermelon)
        canvas.create_text(mode.width/2, mode.height*3/4, text = 'START GAME',
                           font = 'Arial 7 bold')

    def mousePressed(mode, event):
        if (event.x < mode.width/2+50 and event.x > mode.width/2-50 and
            event.y < mode.height*3/4+50 and event.y > mode.height*3/4-50):
            mode.app.setActiveMode(mode.app.gameMode)

class GameMode(Mode):
    def appStarted(mode):
        mode.score = 0
        mode.dy1 = random.randint(20,30)
        mode.dy2 = random.randint(30,40)
        mode.cy = mode.height
        mode.maxheight = random.randint(mode.height//3, mode.height*2//3)
        mode.cx = random.randint(mode.width//5, mode.width*4//5)
        mode.dx = random.randint(10,20)
        mode.by = mode.height
        mode.bx = random.randint(mode.width//5, mode.width*4//5)
        mode.bitx1 = 0
        mode.bitx2 = 0
        mode.bity = 0
        mode.r = 40
        mode.lives = 3
        mode.counter = 0
        mode.fruitList = []
        mode.randomFruit()
        mode.bombList = []
        mode.bomb = PhotoImage(file = 'Bomb.png')

    def randomFruit(mode):
        mode.fruitList = []
        #images are from https://fruitninja.fandom.com/wiki/Category:Fruit

        mode.watermelon = PhotoImage(file = 'Watermelon.png')
        mode.watermelon_bit1 = PhotoImage(file = 'Watermelon_Bit1.png')
        mode.watermelon_bit2 = PhotoImage(file = 'Watermelon_Bit2.png')

        mode.mango = PhotoImage(file = 'Mango.png')
        mode.mango_bit1 = PhotoImage(file = 'Mango_Bit1.png')
        mode.mango_bit2 = PhotoImage(file = 'Mango_Bit2.png')

        mode.pineapple = PhotoImage(file = 'Pineapple.png')
        mode.pineapple_bit1 = PhotoImage(file = 'Pineapple_Bit1.png')
        mode.pineapple_bit2 = PhotoImage(file = 'Pineapple_Bit2.png')

        mode.coconut = PhotoImage(file = 'Coconut.png')
        mode.coconut_bit1 = PhotoImage(file = 'Coconut_Bit1.png')
        mode.coconut_bit2 = PhotoImage(file = 'Coconut_Bit2.png')

        mode.strawberry = PhotoImage(file = 'Strawberry.png')
        mode.strawberry_bit1 = PhotoImage(file = 'Strawberry_Bit1.png')
        mode.strawberry_bit2 = PhotoImage(file = 'Strawberry_Bit2.png')

        mode.greenApple = PhotoImage(file = 'Green_Apple.png')
        mode.greenApple_bit1 = PhotoImage(file = 'Green_Apple_Bit1.png')
        mode.greenApple_bit2 = PhotoImage(file = 'Green_Apple_Bit2.png')

        mode.redApple = PhotoImage(file = 'Red_Apple.png')
        mode.redApple_bit1 = PhotoImage(file = 'Red_Apple_Bit1.png')
        mode.redApple_bit2 = PhotoImage(file = 'Red_Apple_Bit2.png')

        mode.kiwi = PhotoImage(file = 'Kiwi.png')
        mode.kiwi_bit1 = PhotoImage(file = 'Kiwi_Bit1.png')
        mode.kiwi_bit2 = PhotoImage(file = 'Kiwi_Bit2.png')

        mode.banana = PhotoImage(file = 'Banana.png')
        mode.banana_bit1 = PhotoImage(file = 'Banana_Bit1.png')
        mode.banana_bit2 = PhotoImage(file = 'Banana_Bit2.png')

        mode.lemon = PhotoImage(file = 'Lemon.png')
        mode.lemon_bit1 = PhotoImage(file = 'Lemon_Bit1.png')
        mode.lemon_bit2 = PhotoImage(file = 'Lemon_Bit2.png')

        mode.lime = PhotoImage(file = 'Lime.png')
        mode.lime_bit1 = PhotoImage(file = 'Lime_Bit1.png')
        mode.lime_bit2 = PhotoImage(file = 'Lime_Bit2.png')

        mode.orange = PhotoImage(file = 'Orange.png')
        mode.orange_bit1 = PhotoImage(file = 'Orange_Bit1.png')
        mode.orange_bit2 = PhotoImage(file = 'Orange_Bit2.png')

        mode.plum = PhotoImage(file = 'Plum.png')
        mode.plum_bit1 = PhotoImage(file = 'Plum_Bit1.png')
        mode.plum_bit2 = PhotoImage(file = 'Plum_Bit2.png')

        mode.pear = PhotoImage(file = 'Pear.png')
        mode.pear_bit1 = PhotoImage(file = 'Pear_Bit1.png')
        mode.pear_bit2 = PhotoImage(file = 'Pear_Bit2.png')

        mode.passionFruit = PhotoImage(file = 'Passionfruit.png')
        mode.passionFruit_bit1 = PhotoImage(file = 'Passionfruit_Bit1.png')
        mode.passionFruit_bit2 = PhotoImage(file = 'Passionfruit_Bit2.png')

        mode.peach = PhotoImage(file = 'Peach.png')
        mode.peach_bit1 = PhotoImage(file = 'Peach_Bit1.png')
        mode.peach_bit2 = PhotoImage(file = 'Peach_Bit2.png')

        mode.fruits = {'watermelon':mode.watermelon,'mango':mode.mango,
                  'pineapple':mode.pineapple,
                  'coconut':mode.coconut,'strawberry':mode.strawberry,
                  'greenApple':mode.greenApple,'redApple':mode.redApple,
                  'kiwi':mode.kiwi,
                  'banana':mode.banana,'lemon':mode.lemon,'lime':mode.lime,
                  'orange':mode.orange,
                  'plum':mode.plum,'pear':mode.pear,
                  'passionFruit':mode.passionFruit,
                  'peach':mode.peach}

        mode.bit1 = {'watermelon':mode.watermelon_bit1,'mango':mode.mango_bit1,
                'pineapple':mode.pineapple_bit1,'coconut':mode.coconut_bit1,
                'strawberry':mode.strawberry_bit1,
                'greenApple':mode.greenApple_bit1,
                'redApple':mode.redApple_bit1,'kiwi':mode.kiwi_bit1,
                'banana':mode.banana_bit1,
                'lemon':mode.lemon_bit1,'lime':mode.lime_bit1,
                'orange':mode.orange_bit1,
                'plum':mode.plum_bit1,'pear':mode.pear_bit1,
                'passionFruit':mode.passionFruit_bit1,'peach':mode.peach_bit1}

        mode.bit2 = {'watermelon':mode.watermelon_bit2, 'mango':mode.mango_bit2,
                'pineapple':mode.pineapple_bit2,'coconut':mode.coconut_bit2,
                'strawberry':mode.strawberry_bit2,
                'greenApple':mode.greenApple_bit2,
                'redApple':mode.redApple_bit2,'kiwi':mode.kiwi_bit2,
                'banana':mode.banana_bit2,
                'lemon':mode.lemon_bit2,'lime':mode.lime_bit2,
                'orange':mode.orange_bit2,
                'plum':mode.plum_bit2,'pear':mode.pear_bit2,
                'passionFruit':mode.passionFruit_bit2,'peach':mode.peach_bit2}

        mode.fruitChoice=random.choice(['watermelon','mango','pineapple',
                                       'coconut','strawberry','greenApple',
                                       'redApple','kiwi','banana','lemon',
                                       'lime','orange','plum','pear',
                                       'passionFruit','peach'])

##        mode.fruits = random.choice([mode.watermelon,mode.mango,mode.pineapple,
##                             mode.coconut,mode.strawberry,
##                             mode.greenApple,mode.redApple,mode.kiwi,
##                             mode.banana,mode.lemon,mode.lime,
##                             mode.orange,mode.plum,mode.pear,
##                             mode.passionFruit,mode.peach])
        #mode.fruitList.append(mode.fruits)        

    def timerFired(mode):
        mode.doMove()
        mode.counter += 1
        if mode.counter >= random.choice([50,50,50,75,75,100,100,150]):
            mode.randomFruit()
            #mode.bomb()
            mode.bombList.append(mode.bomb)
            mode.counter = 0
        elif mode.cy == mode.height:
            mode.lives -= 1
            mode.randomFruit()
            mode.dy1 = abs(mode.dy1)
            mode.cx = random.randint(mode.width//5, mode.width*4//5)
        elif mode.lives == 0:
            mode.app.setActiveMode(mode.app.gameOverMode)
            mode.lives = 3
            
    def doMove(mode):
        mode.cy -= mode.dy1
        mode.dy1 -= .5
        mode.cx += mode.dx
        mode.by -= mode.dy2
        mode.bx += mode.dx
        if mode.cy < mode.maxheight:
            mode.dy1 = -mode.dy1
        elif mode.by < mode.maxheight:
            mode.dy2 = -mode.dy2

    def mouseDragged(mode, event):
        #for fruit in mode.fruitList:
            dist = ((mode.cx - event.x)**2 + (mode.cy - event.y)**2)**.5
            dist2 = ((mode.bx - event.x)**2 + (mode.by - event.y)**2)**.5
            if dist <= mode.r:
                mode.score += 1
                #mode.fruitList.pop(fruitList.index(fruit))
                #print (mode.fruitChoice)
                mode.cx = random.randint(mode.width//5, mode.width*4//5)
                mode.cy = mode.height
                mode.dy1 = abs(mode.dy1)
                mode.randomFruit()
            if dist2 <= mode.r:
                mode.lives = 0
                mode.app.setActiveMode(mode.app.gameOverMode)
                mode.lives = 3

    def redrawAll(mode, canvas):
        mode.background = PhotoImage(file ='Background.png')
        canvas.create_image(300,200,image=mode.background)
        canvas.create_text(mode.width/5, mode.height/8,
                           text = f'Score: {mode.score}',font = 'Arial 26 bold')
        canvas.create_text(mode.width*4/5, mode.height/8,
                           text = f'Lives: {mode.lives}',font = 'Arial 26 bold')
        #for fruit in mode.fruitList:
            #print(fruit)
        canvas.create_image(mode.cx,mode.cy,image=mode.fruits[mode.fruitChoice])
        #for bomb in mode.bombList:
        canvas.create_image(mode.bx,mode.by,image=mode.bomb)

class GameOverMode(Mode):
    def redrawAll(mode,canvas):
        mode.background = PhotoImage(file ='Background.png')
        canvas.create_image(300,200,image=mode.background)
        font = 'Arial 26 bold'
        canvas.create_text(mode.width/2,
                           100, text='Game Over!', font=font)
        canvas.create_text(mode.width/2, 150,
                           text = f'Score: 0',#{GameMode.score}',
                           font = font)
        mode.watermelon = PhotoImage(file = 'Watermelon.png')
        canvas.create_image(mode.width/2,mode.height*3/4,
                            image = mode.watermelon)
        canvas.create_text(mode.width/2, mode.height*3/4, text = 'Play Again',
                           font = 'Arial 7 bold')

    def mousePressed(mode, event):
        if (event.x < mode.width/2+50 and event.x > mode.width/2-50 and
            event.y < mode.height*3/4+50 and event.y > mode.height*3/4-50):
            mode.app.setActiveMode(mode.app.gameMode)
            
    
class MyModalApp(ModalApp):
    def appStarted(app):
        app.startScreenMode = StartScreenMode()
        app.gameMode = GameMode()
        app.gameOverMode = GameOverMode()
        app.setActiveMode(app.startScreenMode)

MyModalApp(width = 600, height = 400)
